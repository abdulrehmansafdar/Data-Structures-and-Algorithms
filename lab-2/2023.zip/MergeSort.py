import funcs
import Prob2
import time
def MergeSort(array,start,end):
    if(start<end):
        mid = (start+end)//2
        MergeSort(array,start,mid)
        MergeSort(array,mid+1,end)

        Merge(array,start,mid,end)

def Merge(array,start,mid,end):
    L = mid -start+1
    R = end- mid
    L_array = array[start:mid+1]
    R_array = array[mid+1:end+1]
    i=0
    j=0
    
    
    k=start
    while(i<len(L_array) and j<len(R_array)):
        if(L_array[i]<=R_array[j]):
            array[k] = L_array[i]
            i+=1
        else:
            array[k] = R_array[j]
            j+=1
        k+=1

    while(i<L):
        array[k] =L_array[i]
        k+=1
        i+=1
    while(j<R):
        array[k] = R_array[j]
        j+=1
        k+=1
    return array

X = Prob2.RandomArray(30000)

if __name__ == "__main__":
    start_time = time.perf_counter()
    MergeSort(X, 0, len(X) - 1)
    end_time = time.perf_counter()
    runtime = end_time - start_time

    print(X)
    isSorted = funcs.is_sorted(X)
    print(f"Runtime of Merge sort is : {runtime} seconds, is sorted = {isSorted}")

    # store the array in a csv file
    import csv
    with open('MergeSort.csv', 'w', newline='') as f:
        writer = csv.writer(f, delimiter='\n')
        writer.writerows([X])
    
    

    
